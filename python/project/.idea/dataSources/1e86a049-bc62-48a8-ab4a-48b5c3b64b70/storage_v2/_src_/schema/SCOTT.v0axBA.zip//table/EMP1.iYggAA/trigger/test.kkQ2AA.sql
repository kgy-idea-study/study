create trigger "test"
  before insert
  on EMP1
  for each row
BEGIN
  SELECT * from emp1;
end
  /

