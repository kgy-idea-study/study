create trigger "tri_test"
  before insert
  on DEPT
  for each row
BEGIN
  select * from emp;
END;
/

