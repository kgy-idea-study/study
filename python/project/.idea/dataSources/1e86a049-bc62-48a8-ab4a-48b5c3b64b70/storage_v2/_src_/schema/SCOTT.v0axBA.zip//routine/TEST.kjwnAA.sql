create function test(table1 in varchar2) return number is
  v_sal number(7, 2);
  v_sql varchar2(2000) := '';
begin
  v_sql := 'select nvl(sal, 0) from ' || table1 || ' where rownum = 1';

  execute immediate v_sql
    into v_sal;
  return v_sal;

  -- execute immediate用法1：立刻执行sql语句
  --v_sql := 'create or replace view myview as select id,name from student';
  -- execute immediate v_sql;

  --- execute immediate用法2：立刻执行sql语句，并赋值给某个变量
  -- v_sql := 'select count(1) from student';
  -- execute immediate v_sql into v_num;

  -- execute immediate用法3：带参数的sql
  -- v_sql:='select * from student t where t.name=:1 and t.age=:2'; 
  -- execute immediate v_sql using 'ZhangSan',23;
end test;
/

